# 注解伤寒论数据集 v2 MVP Safe 说明

## 构建来源

- 来源数据：`data/processed/zjshl_dataset_v2`
- 目标：为 MVP 第一版提供默认可用的安全版数据底座。
- 原则：优先隔离高风险数据，而不是追求一次性完美修复。

## 本版策略

- `annotation_links.json`：默认停用，safe 包中已置空。
- `annotations.json` / `passages.json` 中注解类记录的 `anchor_passage_id`：已清空，避免误把未验明的挂接关系带入 MVP。
- `chapters.json.role_breakdown`：已按 `chapter_stats.json.role_breakdown_v2` 修正为 v2 当前口径。
- `main_passages.json`：已排除 435 条低置信度主条；保留的短条目中，有 111 条被降为非 primary。
- `chunks.json`：已排除 435 个低置信度切片，并额外过滤 101 个过短切片。

## Safe 后规模

- passages：1841（保留全量总账）
- main_passages：777（其中 primary=666，secondary=111）
- annotations：629（文本保留，默认不参与 MVP 证据链）
- annotation_links：0
- chunks：583
- ambiguous_passages：450（保留为人工复核清单）

## MVP 使用建议

- 主检索层：优先使用 `chunks.json`。
- 主证据层：优先使用 `main_passages.json` 中 `retrieval_primary = true` 的记录。
- 辅助回查层：`passages.json` 保留全量文本，可用于人工核对或后续版本扩展。
- 注解证据层：本版默认不启用，待后续人工复核或重新生成 link 后再恢复。
